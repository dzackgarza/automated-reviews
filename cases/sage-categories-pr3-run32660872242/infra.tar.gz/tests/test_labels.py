"""Proof for the canonical label taxonomy, its planner, and its gh installer.

Semantic behavior is proven in pure functions against the real packaged artifact and
real gh-shaped data (``compute_label_actions``, ``label_commands``, ``RemoteLabel``
parsing). The gh boundary is proven against real ``gh`` invocations — offline
``--version`` success and a real nonzero-exit failure — with no mocks, per
POLICY.NO_MOCK_PROOF. ``install_labels`` is proven end-to-end against real repositories:
a read-only no-op against this repo, and a real failing create against a public repo the
CI token cannot write.
"""

import json
import subprocess
import sys
from pathlib import Path

import pytest
from pydantic import ValidationError

from ai_review_ci.labels import (
    Label,
    LabelMisalignment,
    LabelPlan,
    RemoteLabel,
    Taxonomy,
    _fetch_remote_labels,
    _gh,
    compute_label_actions,
    install_labels,
    label_commands,
    label_misalignment_messages,
    load_taxonomy,
)

REQUIRED_CATEGORIES = {"type", "scope", "status", "area", "complexity"}


# --- pure: taxonomy + planner + command mapping (real artifact, real data) ---


def test_shipped_taxonomy_loads_and_is_well_formed() -> None:
    taxonomy = load_taxonomy()
    assert taxonomy, "packaged taxonomy must be non-empty"
    names = [label.name for label in taxonomy]
    assert len(names) == len(set(names)), "packaged taxonomy has duplicate names"
    assert {label.category for label in taxonomy} == REQUIRED_CATEGORIES


def test_missing_labels_are_created() -> None:
    taxonomy = load_taxonomy()
    plan = compute_label_actions({}, taxonomy)
    assert plan.create == taxonomy
    assert plan.update == ()
    assert plan.unchanged == ()


def test_exact_match_is_unchanged() -> None:
    taxonomy = load_taxonomy()
    remote = {label.name: RemoteLabel(name=label.name, color=label.color, description=label.description) for label in taxonomy}
    plan = compute_label_actions(remote, taxonomy)
    assert plan.unchanged == taxonomy
    assert plan.create == ()
    assert plan.update == ()


def test_color_drift_is_an_update_case_insensitively() -> None:
    label = Label(name="bug", color="D73A4A", description="Something isn't working", category="type")
    same = {"bug": RemoteLabel(name="bug", color="d73a4a", description="Something isn't working")}
    assert compute_label_actions(same, [label]).unchanged == (label,)
    drifted = {"bug": RemoteLabel(name="bug", color="000000", description="Something isn't working")}
    assert compute_label_actions(drifted, [label]).update == (label,)


def test_description_drift_is_an_update() -> None:
    label = Label(name="epic", color="5319e7", description="Canonical description", category="scope")
    remote = {"epic": RemoteLabel(name="epic", color="5319e7", description="stale description")}
    assert compute_label_actions(remote, [label]).update == (label,)


def test_remote_labels_outside_taxonomy_are_left_untouched() -> None:
    label = Label(name="bug", color="d73a4a", description="Something isn't working", category="type")
    remote = {
        "bug": RemoteLabel(name="bug", color="d73a4a", description="Something isn't working"),
        "kilo-triaged": RemoteLabel(name="kilo-triaged", color="faf74f", description="Auto-generated"),
    }
    plan = compute_label_actions(remote, [label])
    assert plan.unchanged == (label,)
    assert plan.create == ()
    assert plan.update == ()


def test_canonical_present_only_as_case_variant_is_a_misalignment_not_a_create() -> None:
    # #217: a repo carrying `Bug` where the canonical name is `bug` must NOT plan a
    # create (gh rejects it case-insensitively with a cryptic "label already exists").
    # It is surfaced as an explicit misalignment naming remote+canonical instead.
    label = Label(name="bug", color="d73a4a", description="Something isn't working", category="type")
    remote = {"Bug": RemoteLabel(name="Bug", color="d73a4a", description="Something isn't working")}
    plan = compute_label_actions(remote, [label])
    assert plan.create == ()
    assert plan.update == ()
    assert plan.unchanged == ()
    assert plan.misaligned == (LabelMisalignment(canonical=label, remote_variants=("Bug",)),)


def test_exact_match_is_not_treated_as_a_variant_misalignment() -> None:
    # Exact matching is preserved: an exact-name match is unchanged, never a variant.
    label = Label(name="bug", color="d73a4a", description="Something isn't working", category="type")
    remote = {"bug": RemoteLabel(name="bug", color="d73a4a", description="Something isn't working")}
    plan = compute_label_actions(remote, [label])
    assert plan.unchanged == (label,)
    assert plan.misaligned == ()


def test_misalignment_message_names_remote_variant_and_required_canonical() -> None:
    # The surfaced message must name the remote label and the required canonical name,
    # framed as a maintainer-fixable misalignment (not laundered into a match).
    label = Label(name="bug", color="d73a4a", description="Something isn't working", category="type")
    remote = {"Bug": RemoteLabel(name="Bug", color="d73a4a", description="Something isn't working")}
    plan = compute_label_actions(remote, [label])
    messages = label_misalignment_messages(plan)
    assert len(messages) == 1
    assert "Bug" in messages[0]
    assert "bug" in messages[0]


def test_label_commands_maps_plan_to_gh_argv_in_order() -> None:
    create = Label(name="new", color="aaaaaa", description="fresh", category="type")
    update = Label(name="old", color="bbbbbb", description="drifted", category="scope")
    plan = LabelPlan(create=(create,), update=(update,), unchanged=())
    assert label_commands(plan, "owner/repo") == (
        ("label", "create", "new", "--repo", "owner/repo", "--color", "aaaaaa", "--description", "fresh"),
        ("label", "edit", "old", "--repo", "owner/repo", "--color", "bbbbbb", "--description", "drifted"),
    )


def test_remote_label_parses_real_gh_list_shape() -> None:
    # The exact JSON shape `gh label list --json name,color,description` returns.
    raw = json.loads('[{"name":"bug","color":"d73a4a","description":"Something isn\'t working"}]')
    parsed = [RemoteLabel.model_validate(entry) for entry in raw]
    assert parsed == [RemoteLabel(name="bug", color="d73a4a", description="Something isn't working")]


def test_remote_label_coerces_null_description() -> None:
    # gh returns "description": null for a label with no description — the common real
    # shape on downstream repos. It must parse (to "") rather than raise.
    raw = json.loads('[{"name":"bug","color":"d73a4a","description":null}]')
    assert [RemoteLabel.model_validate(entry) for entry in raw] == [RemoteLabel(name="bug", color="d73a4a", description="")]


def test_duplicate_taxonomy_names_are_rejected() -> None:
    dup = Label(name="bug", color="d73a4a", description="dup", category="type")
    with pytest.raises((ValidationError, AssertionError)):
        Taxonomy(labels=(dup, dup))


def test_invalid_color_is_rejected() -> None:
    with pytest.raises(ValidationError):
        Label(name="bug", color="not-hex", description="x", category="type")


# --- real gh boundary: fail-loud wrapper, exercised against real gh (no mock) ---


def test_gh_returns_output_on_real_success() -> None:
    # `gh --version` is offline and always exits 0.
    assert "gh version" in _gh(["--version"])


def test_gh_is_fatal_on_real_nonzero_exit(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as excinfo:
        _gh(["not-a-real-gh-subcommand-xyzzy"])
    assert excinfo.value.code == 1
    assert "FATAL: gh not-a-real-gh-subcommand-xyzzy failed" in capsys.readouterr().err


# --- real gh boundary: install_labels end-to-end against real repositories ---


@pytest.mark.gh_boundary
def test_install_labels_is_a_noop_when_taxonomy_matches_remote(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    # Read-only *by construction*: build the taxonomy from a label the repo actually has
    # right now, so the plan is always "unchanged" and nothing is ever mutated —
    # regardless of live label drift. (A hardcoded expectation could instead plan an
    # edit and mutate the real repo.) This still exercises the real fetch/compute/summary
    # path against live gh.
    # Any real label with a non-empty description works (taxonomy descriptions are
    # required non-empty); selecting dynamically avoids coupling to one label's contents.
    remote = _fetch_remote_labels("dzackgarza/ai-review-ci")
    sample = next((label for label in remote.values() if label.description), None)
    assert sample is not None, "expected this repo to have at least one described label to sample"
    taxonomy = tmp_path / "labels.json"
    taxonomy.write_text(json.dumps({"labels": [{"name": sample.name, "color": sample.color, "description": sample.description, "category": "type"}]}))
    install_labels("dzackgarza/ai-review-ci", taxonomy=taxonomy)
    assert "0 created, 0 updated, 1 already current" in capsys.readouterr().out


@pytest.mark.gh_boundary
def test_install_labels_fails_loud_on_a_case_variant_misalignment(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    # #217, at the real gh boundary (no mock): take a label this repo actually has and
    # ask the taxonomy for the same name in swapped case. The exact name is absent but
    # present as a case variant, so install_labels must surface an explicit misalignment
    # (naming remote + canonical) and fail loud WITHOUT attempting any doomed gh create.
    remote = _fetch_remote_labels("dzackgarza/ai-review-ci")
    sample = next((label for label in remote.values() if label.description and label.name.swapcase() != label.name and label.name.swapcase() not in remote), None)
    assert sample is not None, "expected a described label whose swapped-case name is not itself a real label"
    variant_name = sample.name.swapcase()
    taxonomy = tmp_path / "labels.json"
    taxonomy.write_text(json.dumps({"labels": [{"name": variant_name, "color": sample.color, "description": sample.description, "category": "type"}]}))
    with pytest.raises(SystemExit) as excinfo:
        install_labels("dzackgarza/ai-review-ci", taxonomy=taxonomy)
    assert excinfo.value.code == 1
    err = capsys.readouterr().err
    assert "FATAL: label misalignment" in err
    assert sample.name in err  # the actual remote label
    assert variant_name in err  # the required canonical name
    assert "gh label create" not in err  # no doomed create was attempted


@pytest.mark.gh_boundary
def test_install_labels_fails_loud_when_a_create_is_rejected(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    # octocat/Hello-World is public (so the read succeeds) but outside this workflow's
    # repo, which the Actions token cannot write to under GitHub's token model — not
    # luck. A label absent there is planned for creation; the create is attempted for
    # real, gh exits nonzero, and install_labels fails loud (POLICY.FAIL_OPEN). No mock.
    taxonomy = tmp_path / "labels.json"
    taxonomy.write_text(json.dumps({"labels": [{"name": "zz-ai-review-ci-probe", "color": "ededed", "description": "probe", "category": "type"}]}))
    with pytest.raises(SystemExit):
        install_labels("octocat/Hello-World", taxonomy=taxonomy)
    # Prove the create step is what failed loud, not the fetch.
    assert "gh label create failed" in capsys.readouterr().err


# --- token-scoping isolation (#218): the real-boundary gh tests are deselected
#     from the default (tokenless) QC tier and only run under the gh_boundary
#     marker, which the isolated token-scoped `test-gh-boundary` recipe selects.


def _collect_test_labels(*extra_args: str) -> str:
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "--collect-only", "-q", *extra_args, "tests/test_labels.py"],
        cwd=root,
        text=True,
        capture_output=True,
        check=False,
    )
    return result.stdout + result.stderr


def test_gh_boundary_label_tests_are_deselected_by_default_and_marker_selectable() -> None:
    boundary_tests = (
        "test_install_labels_is_a_noop_when_taxonomy_matches_remote",
        "test_install_labels_fails_loud_when_a_create_is_rejected",
    )

    default_collection = _collect_test_labels()
    for name in boundary_tests:
        assert name not in default_collection, f"{name} must be deselected from the default tokenless tier run"
    # The offline gh-wrapper tests need no token and must keep running by default.
    assert "test_gh_returns_output_on_real_success" in default_collection

    marked_collection = _collect_test_labels("-m", "gh_boundary")
    for name in boundary_tests:
        assert name in marked_collection, f"{name} must be selectable via the gh_boundary marker"
    assert "test_gh_returns_output_on_real_success" not in marked_collection


def test_taxonomy_description_cannot_exceed_the_github_limit() -> None:
    """GitHub rejects a description over 100 characters, so the taxonomy cannot carry one."""
    with pytest.raises(ValidationError):
        Label(name="x", color="d93f0b", description="d" * 101, category="status")

    assert Label(name="x", color="d93f0b", description="d" * 100, category="status").description
