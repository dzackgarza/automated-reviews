# Agent Rules

## Issue-Scoped PR Lifecycle

Policy, QC, reviewer, workflow, and gate changes must be issue-first.
Do not accumulate local changes and then invent a PR scope around them.
The work-unit issue is the draft: keep the story, scope, acceptance criteria, proof obligations, implementation checklist, blocker state, and planning decisions in the issue body or comments.
Do not open a draft PR to hold planning state.
Before writing code:

- identify the existing triaged issue or create one with the original problem, policy risk, and acceptance criteria;
- update that issue with the plan, proof obligations, checklist, and expected review evidence before broad implementation continues;
- keep the PR diff limited to that work-unit issue and its evidence; unrelated reopened issues require separate branches/PRs;
- open the PR when implementation starts, synthesize its body from the issue acceptance criteria and the Policy Alignment Gate, and refresh that synthesis before review;
- use the first coherent push to enter the automated PR review loop; `test-ci` and slop review run in parallel so architectural feedback arrives before local polishing drifts;
- request review only after tests/evidence and adversarial policy review are complete;
- route returned review feedback through [[pr-feedback-triage/SKILL|pr-feedback-triage]]: every substantive item receives a visible thread- or surface-local disposition, and accepted or modified feedback receives committed, proven remediation before any positive reply.

If a branch is discovered to contain a broad, untriaged, or policy-poisoned diff, close or abandon the PR rather than trying to salvage it by summary wording.
Recreate the work from `origin/main` on an issue-scoped branch.

## QC Delegation

The stance behind this section — QC is not opt-in, local overrides are banned, a rule is right for all repositories or wrong for all of them — is stated in [CONTRIBUTING.md](./CONTRIBUTING.md). What follows is the mechanics.

- Treat `~/ai-review-ci` as the authoritative QC implementation.
  Downstream repositories carry only thin `test-commit`, `test-push`, and `test-ci` gate recipes that delegate to this repo.

- Every command that loads a central justfile from another repository must preserve the caller repository with `-d .`:

  ```justfile
  test-commit:
      @just -f ~/ai-review-ci/justfiles/python.just -d . test-commit

  test-push:
      @just -f ~/ai-review-ci/justfiles/python.just -d . test-push

  test-ci:
      @just -f ~/ai-review-ci/justfiles/python.just -d . test-ci
  ```

- Apply the same caller-root rule to nested central calls.
  Language justfiles calling `shared.just`, and Sage calling Python QC, must include `-d .` on every nested `just -f` invocation.

- Do not patch a downstream repository first when a shared QC command runs in the wrong directory.
  Fix the central scaffold or central language justfile in this repository, then reinstall or recopy downstream only if the downstream file itself is stale.

- Treat public gate recipe changes as an atomic central-and-downstream migration.
  Updating the central justfiles, scaffolds, doctor, or global hooks is incomplete until every governed downstream default branch exposes the same public recipes.
  `install-qc-scaffold` intentionally refuses to overwrite repo-owned justfiles, so a scaffold edit updates new installations only; explicitly roll the thin delegation block out to existing downstream repositories before a global hook begins calling the new recipe names.

- Prove caller-root fixes with a red test before editing the scaffold or justfile.
  Use a real temporary target repository whose target-specific preflight failure differs from the failure produced in `~/ai-review-ci/justfiles`.

## Testing Central QC Changes

- Do not run central QC recipes against `~/ai-review-ci` as proof of behavior.
  This repository owns the checkers, rules, and justfiles; self-scanning the checker implementation is not the boundary those recipes are meant to prove.

- Proper proof for central QC behavior uses repo-owned canonical fixtures.
  Add or update "bad" target-code fixtures that intentionally violate the policy under test, then run the relevant justfile recipes against those fixture repositories or fixture worktrees.

- The fixture suite must prove the downstream caller contract: the recipe receives a caller repository with `-d .`, scans that caller's target files, reports the expected finding, and does not diagnose `~/ai-review-ci` implementation files as the subject under review.

- Treat self-QC findings as invalid proof until the target boundary is established.
  For example, a rule that bans `try` statements may itself contain code or text about `try`; diagnosing that self-reference starts a false triage loop, not a real product failure.

## False-Positive Triage: Whitelist vs Boundary Typing

Static dead-code detection (vulture) is resolution-free token matching: a name is "used" iff the token appears in a use position in the scanned corpus.
It has no scopes, types, or inheritance, so it cannot see framework dispatch — and the shared whitelist is its designed input channel for exactly those facts, the same way type stubs are the type checker's channel.
That analogy is the triage rule: classify every claimed false positive by *whose fact* it is before touching any suppression surface.

1. **First prove it is not a true positive.** A finding on an accepted-but-ignored parameter, an orphaned helper, or a dead branch is the gate working.
   Fix the downstream code; never suppress.
   (Precedent: `research#48`, the sole true positive among 23 findings.)

2. **External-framework dispatch facts → shared whitelist or class rule, here.** If an external framework calls the name by protocol or reflection (Sage coercion hooks `_neg_`/`_add_`, category machinery `ElementMethods`/`super_categories`, pydantic validators, pytest hooks), no downstream convention can ever make the use visible — the caller is outside any scannable corpus.
   These are version-stable, write-once facts.
   Prefer class mechanisms over name enumeration: `ignore_decorators` for decorator-marked declarations, `exclude` patterns for whole-file non-runtime fixtures (`*_typecheck.py`), name entries in `tool-artifacts/vulture_whitelist.py` only when no class mechanism exists.
   Requests arrive as issues on this repo with dispatch evidence; the fix is an owner commit here.

3. **Downstream type facts → fix the boundary, not the whitelist.** If the finding exists because the downstream repo patched types at the use site — a `TYPE_CHECKING`-only method declaration compensating for a loose stub, a declared contract living outside the repo's declared-interface convention, stub parameter names — the correct fix is downstream: extend the repo's stub subtree so the base class declares the member (an override of an upstream-declared name needs no suppression under any resolution-aware tool, and the use-site patch that vulture trips on disappears), and keep declared contracts in the repo's single declaration convention (`@abstract_method` / stub files).
   Whitelist entries for such findings are provisional debt: admissible only to unblock, recorded with the downstream fix that retires them, and removed once it lands.

4. **Never create per-repo suppression surfaces.** A repo-writable whitelist, ignore file, or override hook is self-service validator silence: the gated agent appends its own finding and pushes.
   All suppression stays in this repo, owner-gated.
   The boundary-crossing friction is the control.

The one-line test: *if the fact is about an external framework's dispatch, declare it here once; if the fact is about the downstream repo's own types, the repo fixes its types.*

## Semgrep Findings

- Separate Semgrep rule provenance from finding ownership.
  Paths under `~/ai-review-ci/tool-configs/` identify the rule config; the finding target path identifies the code being checked.

- Do not conclude that QC scanned its own files because output mentions `tool-configs/semgrep.yml`. Confirm the process cwd, the target paths, and the target count before diagnosing wrong-repo scanning.

- A downstream report that “Semgrep found issues about CI files” is a cwd/provenance triage problem until target paths prove otherwise.
  Reproduce the run from the target repository and inspect the exact reported paths before editing rules or suppressions.

## Hook Tiers

- The three gate boundaries are intentional: `pre-commit` runs `just test-commit`, `pre-push` runs `just test-push`, and required PR CI runs `just test-ci`.

- Commit failures are direct local repair and push failures are ordinary project/test repair.
  Neither enters the PR-feedback triage workflow or requires an independent remediation role.

- Slop/style/coverage findings during commit or push indicate a gate-tier or delegation problem.
  Policy-sensitive findings belong in `test-ci`, where independent anti-golfing triage and PR review run as separate acceptance channels.
  Do not reinstall hooks or weaken QC until the active hook path, hook contents, and delegated cwd have been verified.

> Optimized tool-use workflow for agents: see [SDL.md](./SDL.md).

# Policy Alignment Gate

Every PR against this repo must reconcile against the burned-bridge policy before review is requested or before it merges.

Why the burden sits in the definition of done rather than in CI, why an argument for relaxing a rule carries no weight by default, and the PR #143 case where a merged "fix" silenced a detector for every downstream consumer: [CONTRIBUTING.md](./CONTRIBUTING.md).

## Canonical policy source (self-contained — no external fetch)

The authoritative policy is owned by this repo under `skills/`. Load it from the checkout:

- `skills/policy-index/SKILL.md` and `skills/policy-index/references/policies.md` — the `POLICY.*` records and their **Invalid local fixes**.
- `skills/policy-index/references/red-flags.md` — the red-flag inventory.
- `skills/policy-index/references/runtime-control-flow.md` — runtime control-flow red flags.

Do not rely on globally-installed skills: remote review/coding agents (Codex, Jules, cloud runs) do not have them.
The in-repo copy is the contract — this repo is the canonical home; other machines install these skills as symlinks via `just install-skills`.

## Tier 0 — every PR

Before requesting review or merging, the PR body must state:

- Which `POLICY.*` records the change touches or risks.
- That no **Invalid local fix** from those records was introduced — no new fallback, runtime default, optional core-state, swallowed error, or partial-success path added to make required work look successful after it should have failed loudly.

Empty and falsy literals are not exceptions.
A fallback whose value is a placeholder — the canonical `POLICY.FAIL_OPEN` record names `None`, `[]`, `{}`, and `false`; empty strings behave the same way — is a `POLICY.FAIL_OPEN` violation, not "safe boundary normalization."
Genuinely optional product state is represented as an explicit typed/semantic state at the owned boundary, never laundered through an empty default.

## Tier 1 — PRs that change the QC tooling itself

Any PR touching `tool-configs/`, `reviews/`, the detectors, or QC `justfiles/` additionally must carry an **adversarial regression-lock**:

- A fixture (`// ruleid:` or equivalent) proving each previously-flagged banned pattern **still fires** after the change.
  A precision fix narrows by **position** — excluding genuine boolean/control-flow uses — never by **value**. No fallback value is reclassified as safe.
- An explicit statement that the change weakens no `POLICY.*` and converts no true finding into scanner silence.

This is the gate PR #143 would have failed: a `ruleid` fixture on `?? ""` / `?? []` / `?? {}` makes any future empty-literal whitelist a red test.

See `# Review Guidelines` → Evidence Expectations for the reviewer-side counterpart, and the wiki page [Policy Alignment Gate](https://github.com/dzackgarza/ai-review-ci/wiki/Policy-Alignment-Gate) for the full rationale.

# Review Guidelines

These are additional requirements for reviewing agent work.
They do not replace the reviewer’s normal role, repo-specific standards, or technical judgment.
They provide the failure model that should shape the review.

The task is not merely to review a PR. The task is to decide whether a completion claim is true under the original objective.
The standard is full, correct, provable completion against the original requirements and repo guidelines.
Anything less is incomplete work that must not be treated as a win.

## Failure Model

Agents systematically produce impressive non-completion.
Common patterns are: polished summaries that imply finished work, caveats that quietly narrow the goal, reclassification without proof, delegated discovery presented as resolution, process language that substitutes for evidence, merged PRs treated as completion, passing checks treated as semantic proof, and artifacts that look substantial while leaving required work unowned.

Treat the agent’s summary, PR description, closing comment, issue closure, “goal completed” statement, and self-reported validations as untrusted.
They may be diagnostic pointers, but they are not evidence that the work is complete.
The evidence is the original issue or task, the code diff, tests, source/runtime facts, review comments, and produced artifacts.

## Decisive Invariants

Preserve the original success condition.
Read the original issue or task before accepting any restatement of it.
Keep its quantifiers intact: “all,” “complete,” "full subset," “zero remaining,” and similar terms cannot be quietly narrowed to examples, partial coverage, known blockers, or whatever the PR happened to touch.

Nothing required may disappear silently.
A required work family must be implemented, explicitly falsified, or validly reclassified with evidence that satisfies the issue’s own standard.
Partial implementation is not completion.
Future work is not completion.
Count reduction is not completion.
Resolved review threads are not completion.
Passing checks are not completion.
Substantial-looking work is not completion.
“Better than before” is not completion.

Goal substitution is the main thing to detect.
Ask whether the submitted work solves the original problem or merely produces a narrower artifact: cleaner metadata, a partial subset, a better explanation, a new issue, a renamed scope, a local workaround, or proof that someone should investigate later.

Technically correct administrative artifacts can be goal substitution.
A well-written issue, comment, audit note, scope statement, or enumeration of remaining work may be required, but it does not complete implementation, testing, proof, or downstream cleanup.
If the original task requires execution, the artifact is only useful insofar as it drives that execution; it must not become the stopping point.

Treat self-scoped remaining-work lists as a severe completion-laundering pattern.
When an agent is asked to enumerate remaining work, the domain is the original full completion requirement, not the agent’s intended subset, the PR’s current shape, a closeability criterion, or the work left after deferral and reclassification.
A valid enumeration subtracts only artifact-proven completed work from the original contract.
Deferrals, routed follow-ups, owner changes, and truthful incompletion notes remain unresolved work unless the original task explicitly made that administrative routing the whole deliverable.

If an agent repeats a narrowed enumeration after being corrected, treat that as a hard misalignment signal, not as an innocent wording issue.
The reviewer should identify the original full requirement, the scope the agent substituted, and the required work hidden by that substitution.

Silent reclassification is not resolution.
If the PR says remaining work is out-of-scope, research-owned, stub-owned, plugin-owned, downstream-owned, or future-owned, require evidence from the relevant source/runtime behavior, repo boundary, or original acceptance criteria.
A sentence in the PR description is not enough.

Ownership boundaries matter.
The submitting repo must prove its own claimed behavior and do the blocker forensics required by its own issue.
Do not require a receiving or downstream repo to classify another project’s internal uncertainty unless the original issue explicitly made that part of acceptance.
When an external issue is created, it should be written for that receiving repo, not for a reader who already knows the submitting repo’s context.

## Evidence Expectations

Review tests as evidence, not as decoration.
Valid tests exercise the real production path or semantic requirement.
Be skeptical of helper-only tests, tautologies, assertions of the implementation’s own output, bypasses around the runtime/plugin/stub path, example-only coverage where the issue required full coverage, weakened assertions, and missing invalid-nearby cases where the fix could overgeneralize.

For plugin work, the evidence should usually distinguish valid generic behavior from invalid nearby ordinary Python and should not hard-code a downstream consumer.
For stubs work, the evidence should be source-backed: the upstream surface exists, the stub matches public behavior, no fake API is added, no Any/object opacity escape is introduced, and inherited-method inflation is not used unless source exposes that surface.

Watch for code-level laundering: hard-coded consumer names, support for local research abstractions as if they were external API, fake stubs, broad Any/object escapes, line suppressions, diagnostic filtering, deletion of required data, broad type widening, and any move that makes checks pass by weakening the problem instead of solving it.

## When Acting on Review Feedback

A positive disposition requires a commit.

Do not resolve an accepted review comment until the code/proof remediation is committed and the reply cites the commit.

Never reply “accepted,” “aligned,” “fixed,” “addressed,” or “will address” to a review thread unless the remediation is already committed.
A thread cannot be resolved on intent or future work.

Every substantive review item must receive its visible thread- or surface-local disposition and evidence before resolution.
The canonical field contract and state machine live in [[pr-feedback-triage/SKILL|pr-feedback-triage]]. Do not create top-level disposition ledgers or tracked review-log files.
Migrate legacy ledger-only resolutions by posting the canonical disposition and evidence on each affected thread before treating it as closed.

Review comments are not implementation specs.
The worker must translate accepted feedback into first-principles remediation requirements before assigning implementation.

For each comment:
- Identify the concern.
- Identify the proposed fix.
- Decide whether the concern is true under global + repo policy.
- Decide whether the proposed fix preserves those policies.
- If the concern is true but the fix is wrong, apply a policy-compatible remediation.

## Writing the Review

Write nuanced feedback for an intelligent reader.
Do not force a machine-readable template, a mandatory table, or a simplistic pass/fail label when prose communicates the situation better.
Do make the completion judgment clear: whether the original task can be considered complete, what evidence supports that judgment, and which unresolved requirements block completion if any remain.

Do not foreground effort, progress, good intentions, volume of work, or “substantial” partial implementation when required work remains.
Mention completed pieces only when they are necessary to identify the exact remaining blockers or to prevent redoing already-correct work.
Do not compare incomplete work to “no work done” or “completely fake work”; compare it to the expected standard: the task done correctly, completely, and provably.

When required work remains, lead with the incompleteness and the concrete blockers.
Do not make the reader excavate the missing work from beneath praise, context-setting, or a narrative of what did get done.

Nuance belongs in the evidence and blocker analysis, not in softening the completion standard.
The review should make it easy to finish the work, not easy to feel satisfied with less than the original contract required.

<!-- agent-memory:start -->
# Agent memory

This repository uses the central agent memory vault at `/home/dzack/.agent-memory-vault`.

Project memory key: `projects/github.com__dzackgarza__ai-review-ci/index`.

Repository `.agents` and `.hermes` paths are symlinks to the same vault-owned project directory.

Before changing architecture, search both project and global memory:

```bash
agent-memory search --scope both "<task or subsystem>"
```

Record durable repo-specific lessons with:

```bash
agent-memory add --scope project --type decision --title <title> --content <content>
agent-memory add --scope project --type trap --title <title> --content <content>
agent-memory add --scope project --type advice --title <title> --content <content>
agent-memory add --scope project --type context --title <title> --content <content>
agent-memory add --scope project --type reference --title <title> --content <content>
```

Plan work is card-backed.
Create and update plan cards with `agent-memory plan add` and `agent-memory plan update`, not `agent-memory add --type plan`.

Use `agent-memory retrieve <key>`, `agent-memory update <key>`, and `agent-memory delete <key>` for memory CRUD.

The vault should be committed at all times.
Treat staged or unstaged vault changes as an ephemeral error state.
Before normal memory work resumes, load the bundled vault-maintenance skill with `agent-memory maintain skill vault-maintenance` and follow its referenced check, repair, and commit workflows.

Move reusable lessons during maintenance with:

```bash
agent-memory maintain move <key> --to global/advice
```
<!-- agent-memory:end -->
